$(document).ready(
		function(){
				$("#secrettoken").load('/WebGoat/JWT/secret/gettoken');
		}
	);